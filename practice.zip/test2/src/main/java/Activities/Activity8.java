//package Activities;
//
//import net.bytebuddy.implementation.bytecode.Throw;
//
//public class Activity8 {
//
//   public String  exceptiontest(){
//       new CustomException("msg");
//
//   }
//
//    public static void main(String[] args) {
//
//       Activity8.
//
//    }
//}
