package Activities;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Plane {

    private List<String> passengers;
    private int maxPassengers;
    private Date lastTimeTookOf;
    private Date lastTimeLanded;

    public Plane(int maxPassengers){
        this.maxPassengers=maxPassengers;
        this.passengers=new ArrayList<>();
    }

    public void Onboard(String passenger){

      this.passengers.add(passenger);
    }

    public Date takeOff(){

        this.lastTimeTookOf=new Date();
        return lastTimeTookOf;

    }
    public Date land(){
     this.lastTimeLanded=new Date();
     return lastTimeLanded;

    }

    public Date getlasttimelanded(){

        return lastTimeLanded;

    }
    public List<String> getpassengers(){
        return passengers;
    }
}
