package Activities;

public class Bicycle implements BicycleOperations,BicycleParts{


    public int gears;
    public int currentspeed;
    public Bicycle(int gears,int currentspeed){
        this.gears=gears;
        this.currentspeed=currentspeed;

    }
    public String bicycledesc(){
        return("No of gears are "+ gears + "\nSpeed of bicycle is " + currentspeed);

    }

    @Override
    public void applyBrake(int decrement) {

        currentspeed -= decrement;
    }

    @Override
    public void speedUp(int increment) {

        currentspeed +=increment;
        System.out.println("current speed"+currentspeed);
    }

}
