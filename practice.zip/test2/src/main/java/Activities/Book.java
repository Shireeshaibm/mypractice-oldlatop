package Activities;
 abstract class Book {


     String title;

     public  void setTitle(String s){

         title =s;
     }

     public String getTitle(){

         title="first"+title;

         return title;
     }



 }

