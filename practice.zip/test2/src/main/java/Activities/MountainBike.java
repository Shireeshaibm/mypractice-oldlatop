package Activities;

public class MountainBike extends Bicycle {
  public int seatheight;
  public MountainBike(int gears,int currentspeed,int startheight){

    super(gears, currentspeed);
    seatheight=startheight;

  }
  public void setSeatheight(int newValue){
    seatheight = newValue;
  }
  public String bicycledesc(){

    return (super.bicycledesc()+"\nseatheight is"+seatheight);
  }

}