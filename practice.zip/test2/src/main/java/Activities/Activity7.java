package Activities;

public class Activity7 {

    public static void main(String[] args) {

        MountainBike mb= new MountainBike(4,1,26);

        System.out.println(mb.bicycledesc());
        mb.seatheight=5;

        mb.speedUp(20);
        mb.applyBrake(5);

    }

}
