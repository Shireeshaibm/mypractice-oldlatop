package Activities;

public class Activity6 {

    public static void main(String[] args) throws InterruptedException {

        Plane plane= new Plane(10);

        plane.Onboard("Karen");
        plane.Onboard("swiya");
        plane.Onboard("jotshna");
        plane.Onboard("jocab");
        plane.Onboard("jonathon");
        plane.Onboard("james");
        plane.Onboard("gosling");

        System.out.println(plane.takeOff());
        System.out.println(plane.getpassengers());
         Thread.sleep(1000);
        System.out.println(plane.land());
        Thread.sleep(1000);
        System.out.println(plane.getlasttimelanded());


    }
}
