package Activities;

public interface BicycleOperations {
    public void applyBrake(int decrement);


    public  void speedUp(int increment);


}
