package Activities;

public class MyBook extends Book{

    public static void main(String[] args) {

       MyBook buk = new MyBook();
       buk.setTitle("newnovel");
       System.out.println("name of the book is "+buk.getTitle());

    }


}
