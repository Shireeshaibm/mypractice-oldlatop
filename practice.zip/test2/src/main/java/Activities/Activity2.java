package Activities;

public class Activity2 {
    public static void main(String[] args) {
        int[] numarray={10, 77, 10, 54, -11, 10,-10,10};
        int tens=0;

        for(Integer i:numarray){


            if(i==10){

           tens=tens+10;

            }
        }

        if(tens==30){

         System.out.println("true");

        }else System.out.println("false");

    }
}
