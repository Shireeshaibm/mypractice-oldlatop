package Activities;

public interface BicycleParts {
    public int gears=0;
    public int speed=0;




}
