package Activities;

import org.checkerframework.checker.units.qual.C;

public class Activity1 {

    public static void main(String[] args) {

        Car car = new Car();
        car.make=2014;
        car.color="Black";
        car.transmission="manual";
        car.displaycharacteristics();
        car.accelerate();
        car.brake();

    }




}
