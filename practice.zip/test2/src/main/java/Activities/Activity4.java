package Activities;

public class Activity4 {

    public static void main(String[] args) {
         int act4array[] ={4,3,2,10,9,12,8,1,5,6,7,11};

        System.out.println("before sorting :");

 for(Integer i:act4array){
     System.out.print(+i +",");

 }

 for(int i=0;i<act4array.length;i++){

     for(int j=i+1;j<act4array.length;j++){

         if(act4array[i]>act4array[j]){

             int replace=0;
             replace=act4array[j];
             act4array[j]=act4array[i];
             act4array[i]=replace;


         }

     }
 }

        System.out.println("after array sorting :");
        for(Integer k:act4array){
            System.out.print(+k +" ");

        }


}}
