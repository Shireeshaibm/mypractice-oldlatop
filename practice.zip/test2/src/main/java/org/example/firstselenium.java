package org.example;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class firstselenium {
    public static void main(String args[]){

        WebDriver driver = new ChromeDriver();
        driver.get("https://www.training-support.net/selenium/simple-form");
       String googlepage_title= driver.getTitle();
        System.out.println(googlepage_title);
        String gp=googlepage_title.substring(1,2);

        driver.navigate().to("https://www.selenium.dev/");




        driver.get("https://www.training-support.net/selenium/simple-form");
        driver.navigate().
                to("https://www.selenium.dev/documentation/webdriver/");
        String act_page_title="WebDriver | Seleniu";
        String page_title=driver.getTitle();
        System.out.println(page_title);
        System.out.println(act_page_title.equals(page_title));
        driver.close();
        driver.quit();





    }
}
