package org.example;

public class sizeofdatatypes {

    public static void main(String[] args) {

       String str ="RADAR"; String rev="";

       for(int i =str.length()-1;i>=0;i--){

           rev=rev+str.charAt(i);


       }
       if(rev.equals(str)){
           System.out.println("string is palindrome");
       }else{
           System.out.println("string is not a palindrome");
       }

    }



}
