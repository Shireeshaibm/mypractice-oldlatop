//package org.example;
//
//import javax.swing.*;
//import java.awt.event.KeyEvent;
//import java.awt.event.KeyListener;
//
//public class arrowkeydetector {
//
//
//    public  static void arrowkeys(){
//
//        JFrame frame= new JFrame();
//        frame.setVisible(true);
//        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        frame.setSize(400,400);
//        frame.setFocusable(true);
//        JPanel panel = new JPanel();
//        JLabel UP = new JLabel();
//        JLabel DOWN = new JLabel();
//        JLabel LEFT = new JLabel();
//        JLabel RIGHT = new JLabel();
//      panel.add(UP);
//        panel.add(DOWN);
//        panel.add(LEFT);
//        panel.add(RIGHT);
//
//        UP.setText("up : 0");
//        DOWN.setText("down : 0 ");
//        LEFT.setText("LEFT: 0");
//        RIGHT.setText("RIGHT:0");
//        frame.add(panel);
//
//         frame.addKeyListener(new KeyListener() {
//             @Override
//             public void keyTyped(KeyEvent e) {
//
//             }
//
//             @Override
//             public void keyPressed(KeyEvent e) {
//
//                 int keycode=e.getKeyCode();
//                 switch(keycode){
//                     case KeyEvent.VK_UP:
//                         UP.setText("up:"+upcount);
//
//
//
//                 }
//
//             }
//
//             @Override
//             public void keyReleased(KeyEvent e) {
//
//             }
//         });
//
//
//
//
//
//    }
//
//    public static void main(String args[]){
//
//      arrowkeys();
//    }
//
//
//}
