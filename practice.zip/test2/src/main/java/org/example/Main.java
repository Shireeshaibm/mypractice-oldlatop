package org.example;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.util.Properties;

public class Main {
    public static void main(String[] args) {

        Properties prop = new Properties();
        WebDriver driver = new FirefoxDriver();

     /*   if(prop.get("browser").equals("Firefox")){

         driver = new FirefoxDriver();
        } else  if(prop.get("browser").equals("google")){
             driver = new FirefoxDriver();
             driver= new EdgeDriver();
        }*/

        driver.get("https://www.training-support.net/");
        System.out.println(driver.getTitle());

        System.out.println("Hello world!");

    }
}