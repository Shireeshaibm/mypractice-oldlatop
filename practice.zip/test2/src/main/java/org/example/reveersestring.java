package org.example;

public class reveersestring {
    public static void main(String args[]) {

        reverse("my name is shireesha");


    }

    public static String reverse(String s) {

        String rev="";
        char[] ltrs = s.toCharArray();
        for (int i = ltrs.length-1; i >= 0; i--) {

           rev=rev+ltrs[i];
        }
       System.out.println(rev);
        return  rev;


    }

}

