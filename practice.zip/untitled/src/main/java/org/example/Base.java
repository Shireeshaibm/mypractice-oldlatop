package org.example;

import dev.failsafe.internal.util.Assert;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.List;

import static dev.failsafe.internal.util.Assert.*;

public class Base {
    // public static void main(String[] args) {
    WebDriver driver;

    @BeforeMethod
    public void Launchapp() {
        WebDriverManager.firefoxdriver().setup();
        WebDriver driver = new FirefoxDriver();
    }

    @Test(priority = -1,enabled = false)
    public void test1() {

    /*    1. Verify the website title
        Goal: Read the title of the website and verify the text
        a. Open a browser.
        b. Navigate to ‘https://alchemy.hguy.co/jobs’.
        c. Get the title of the website.
        d. Make sure it matches “Alchemy Jobs – Job Board Application” exactly.
        e. If it matches, close the browser. */
        // Launchapp();
        driver.get("https://alchemy.hguy.co/jobs/");
        String page_title = driver.getTitle();
        System.out.println("title of the page is " + page_title);
        if (page_title.equals("Alchemy Jobs – Job Board Appliction")) {

            System.out.println("page title is correct");
            driver.close();

        } else {

            System.out.println("page title is incorrect");
        }


    }

    @Test(priority = 1,enabled = false)
    public void test2() {
        //Launchapp();
        driver.get("https://alchemy.hguy.co/jobs/");
        String pageheading = driver.findElement(By.cssSelector("h1.entry-title")).getText();
        if (pageheading.equals("Welcome to Alchemy Jobs")) {

            driver.close();
        }

    }


    @Test(priority = 2)
    public void test3() {
 driver.get("https://alchemy.hguy.co/jobs/");
 String url =driver.findElement(By.xpath("//img")).getAttribute("src");
 System.out.println("url of the image is "+url);
 driver.close();

    }

    @Test(priority = 1)
    public void test4(){

        driver.get("https://alchemy.hguy.co/jobs/");
        String sec_heading=driver.findElement(By.xpath("//h2")).getText();
        if(sec_heading.equals("“Quia quis non")){
            System.out.println("heading is matching ");
            driver.close();
        }else{
            System.out.println("heading is not matching ");
        }
    }

    @Test
    public void test5(){

        driver.get("https://alchemy.hguy.co/jobs/");
        List<WebElement> menubar =driver.findElements(By.cssSelector("div.main-navigation"));
        for(WebElement option:menubar){
            if(option.equals("Jobs")){
                option.click();
                String page_title= driver.getTitle();
                System.out.println(page_title);
                if(page_title.contains("Jobs")){

                    System.out.println("we are on jobs page");

                }else{

                    System.out.println("we are on different page");
                }
            }
        }
    }
    @Test(dependsOnMethods = "test5")
    public void test6(){
 WebElement keyword_search=driver.findElement(By.cssSelector("input#search_keywords"));
 keyword_search.sendKeys("testing");
        WebElement location_search=driver.findElement(By.cssSelector("input#search_location"));
        keyword_search.sendKeys("india");



    }

}
