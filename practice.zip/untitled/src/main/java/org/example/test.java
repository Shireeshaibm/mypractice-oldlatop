package org.example;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.checkerframework.checker.units.qual.C;
import org.openqa.selenium.By;
import org.openqa.selenium.Rectangle;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;

public class test {
    public static void main(String args[]){

        //ChromeOptions options= new ChromeOptions();
        WebDriverManager.firefoxdriver().setup();
        FirefoxOptions options = new FirefoxOptions();
        options.addArguments("--headless=new");
        WebDriver driver =new FirefoxDriver(options);
        driver.get("https://the-internet.herokuapp.com/upload");
        Rectangle rect= driver.findElement(By.id("file-submit")).getRect();
        System.out.println(rect.getX()+" " + rect.getY() + " " +rect.height +" " +rect.width);
        System.out.println(driver.findElement(By.id("file-submit")).getCssValue("background-color"));
        System.out.println(driver.findElement(By.id("file-upload")).getCssValue("font-weight"));





    }

}
